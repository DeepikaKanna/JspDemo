package com.capgemini.Exception;

public class EBillException extends Exception{
	
	public EBillException(String message) {
		super(message);
	}
}
