package com.capgemini.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.capgemini.Bean.BillDetails;
import com.capgemini.Bean.ConsumerBean;
import com.capgemini.Dao.IEBillDao;
import com.capgemini.Exception.EBillException;

import com.capgemini.Service.EBillServiceImplt;
import com.capgemini.Service.IEBillService;

/**
 * Servlet implementation class EBillController
 */
@WebServlet("/EBillController")
public class EBillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EBillController() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String operation = (String) request.getParameter("action");
		PrintWriter out = response.getWriter();
		
		System.out.println(operation);
		if(operation!=null && operation.equals("Login")){
			
			String name = request.getParameter("UserName");
			String pwd = request.getParameter("pwd");
			
			if(isValidUser(name, pwd))
				response.sendRedirect("index.html");
			else {
				out.println("Inalid Username or password");
			}	
		}
		
		else if(operation!=null & operation.equals("listConsumers")){
			IEBillService service = new EBillServiceImplt();
			
			try {
				ArrayList<ConsumerBean> list = service.ConsumerList();
				
				 request.setAttribute("bean", list);
				 ServletContext context = getServletContext();
				 RequestDispatcher rd = context.getRequestDispatcher("/Show_Consumer_List.jsp");
				 rd.forward(request, response);
				 
				/*
				getServletContext().setAttribute("bean",list);
				response.sendRedirect("Show_Consumer_List.jsp");
				*/
				
			} 
			catch (EBillException | SQLException e) {
				System.out.println(e.getMessage());
			}
			
		}
		else if(operation!=null && operation.equals("searchConsumer")){
			response.sendRedirect("Search_Consumer.jsp");
		}
		else if(operation!=null && operation.equals("search")){
			System.out.println("Reached else");
			int consumerNumber = Integer.parseInt(request.getParameter("consumerNum"));
			System.out.println("Reached after retrieve");
			//out.println("consumerNumber = " + consumerNumber);
			ConsumerBean bean = new ConsumerBean();
			IEBillService service = new EBillServiceImplt();
			
			try {
				
				bean = service.searchConsumer(consumerNumber);
				
				request.setAttribute("bean", bean);
				request.setAttribute("consumerNumber",String.valueOf(bean.getConsumerNum()));
				//request.setAttribute("consNum", bean.getConsumerNum());
				ServletContext context = getServletContext();
				RequestDispatcher rd = context.getRequestDispatcher("/Show_consumer.jsp");
				rd.forward(request, response);
			} 
			catch (EBillException | SQLException e) {
				System.out.println(e.getMessage());
			} 
		}
		else if(operation!=null && operation.equals("showBillDetails")){
			System.out.println("Reched show bill details");
			int consNum = Integer.parseInt((String)request.getParameter("consNum"));
			
			IEBillService service = new EBillServiceImplt();
			try{
				ArrayList<BillDetails> list = service.getConsumerBills(consNum);
				
				request.setAttribute("bill", list);
				System.out.println("reached before request");
				ServletContext context = getServletContext();
				RequestDispatcher rd = context.getRequestDispatcher("/Show_Bills.jsp");
				 rd.forward(request, response);
			}
			catch(EBillException | SQLException e){
				System.out.println(e.getMessage());
			} 
			
			out.println("Reched show bill details - " + consNum);
		}
		else if(operation!=null && operation.equals("Calculate Bill")){
			
			int custNum = Integer.parseInt(request.getParameter("custNumber"));
			float lastMonthReading = Float.parseFloat(request.getParameter("LastMonthReading"));
			float currMonthReading = Float.parseFloat(request.getParameter("CurrentMonthReading"));
			
			float billAmount = (float)calculateBill(lastMonthReading, currMonthReading);
			
			BillDetails bill = new BillDetails();
			
			bill.setConsumerNum(custNum);
			bill.setMonthReading(currMonthReading);
			bill.setUnitConsumed(currMonthReading - lastMonthReading);
			bill.setBillAmount(billAmount);
			
			IEBillService service = new EBillServiceImplt();
			try{
				int billNum = service.addBillDetails(bill);
				bill.setBillNumber(billNum);
				
				ConsumerBean consumer = new ConsumerBean();
				consumer = service.searchConsumer(bill.getConsumerNum());
				
				out.println("<h3>Welcome "+consumer.getConsumerName()+"</h3>" +
						"<h1>Electricity Bill for Consumer Number - " + bill.getConsumerNum()+ " is </h1></br>"+
						
						"<h3>Units consumed: " + bill.getUnitConsumed() + "</br>"+
						"Bill Amount: " + bill.getBillAmount() +"</h3></br>"
				);
			}
			catch(EBillException | SQLException e){
				request.setAttribute("cusNum", String.valueOf(bill.getConsumerNum()));
				ServletContext context = getServletContext();
				RequestDispatcher rd = context.getRequestDispatcher("/Error.jsp");
				 rd.forward(request, response);
			}
		}
	}
	
	
	private boolean isValidUser(String name,String pwd){
		if(name.equals("Deepika") && pwd.equals("Kanna"))
			return true;
		else return false;
	}
	private double calculateBill(float lastMonthReading, float CurrMonthReading) {
		System.out.println("Reached Calculate Bill");
	
		double bill;
		float unitsConsumed = (CurrMonthReading - lastMonthReading);
		
		bill = (unitsConsumed * 1.15 ) + IEBillDao.FIXEDCHARGE;
		
		return bill;
	}

}
