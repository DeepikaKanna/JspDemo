package com.capgemini.Service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.capgemini.Bean.ConsumerBean;
import com.capgemini.Bean.BillDetails;
import com.capgemini.Exception.EBillException;


public interface IEBillService {
	public abstract ArrayList<ConsumerBean> ConsumerList() throws EBillException, SQLException;
	public abstract ConsumerBean searchConsumer(int consumerNum) throws EBillException, SQLException;
	public abstract ArrayList<BillDetails>getConsumerBills(int consumerNum) throws EBillException,SQLException;
	public abstract int addBillDetails(BillDetails bill) throws EBillException, SQLException;
}
