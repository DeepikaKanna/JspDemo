package com.capgemini.Service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.capgemini.Bean.BillDetails;
import com.capgemini.Bean.ConsumerBean;
import com.capgemini.Dao.EBillDaoImplt;
import com.capgemini.Dao.IEBillDao;
import com.capgemini.Exception.EBillException;

public class EBillServiceImplt implements IEBillService{

	@Override
	public ArrayList<ConsumerBean> ConsumerList() throws EBillException, SQLException {
		IEBillDao dao = new EBillDaoImplt();
		
		ArrayList<ConsumerBean> list = dao.ConsumerList();
		
		return list;
	}

	@Override
	public ConsumerBean searchConsumer(int consumerNum) throws EBillException, SQLException{
		IEBillDao dao = new EBillDaoImplt();
		
		ConsumerBean bean = new ConsumerBean();
		bean = dao.searchConsumer(consumerNum);
		return bean;
	}

	@Override
	public ArrayList<BillDetails> getConsumerBills(int consumerNum)
			throws EBillException, SQLException {
		
		IEBillDao dao = new EBillDaoImplt();
		ArrayList<BillDetails> list = dao.getConsumerBills(consumerNum);
		
		return list;
	}

	@Override
	public int addBillDetails(BillDetails bill) throws EBillException,
			SQLException {
		IEBillDao dao = new EBillDaoImplt();
		int consumerNum = dao.addBillDetails(bill);
		return consumerNum;
	}

}
