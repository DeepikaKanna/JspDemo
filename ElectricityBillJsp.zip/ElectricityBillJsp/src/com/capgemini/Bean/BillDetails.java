package com.capgemini.Bean;

public class BillDetails {
	private int billNumber; 
	private int consumerNum;
	private String billMonth;
	private float monthReading;
	private float unitConsumed;
	private float billAmount;
	
	public int getBillNumber() {
		return billNumber;
	}
	public void setBillNumber(int billNumber) {
		this.billNumber = billNumber;
	}
	public int getConsumerNum() {
		return consumerNum;
	}
	public void setConsumerNum(int consumerNum) {
		this.consumerNum = consumerNum;
	}
	public String getBillMonth() {
		return billMonth;
	}
	public void setBillMonth(String billMonth) {
		this.billMonth = billMonth;
	}
	public float getMonthReading() {
		return monthReading;
	}
	public void setMonthReading(float monthReading) {
		this.monthReading = monthReading;
	}
	public float getUnitConsumed() {
		return unitConsumed;
	}
	public void setUnitConsumed(float unitConsumed) {
		this.unitConsumed = unitConsumed;
	}
	public float getBillAmount() {
		return billAmount;
	}
	public void setBillAmount(float billAmount) {
		this.billAmount = billAmount;
	}
	
	
}
