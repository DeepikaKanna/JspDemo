package com.capgemini.Dao;

import com.capgemini.Bean.ConsumerBean;

public interface IQuerryMapper {
	public static final String CONSUMER_LIST ="SELECT consumer_num,consumer_name,address FROM Consumers";
	public static final String SEARCH_CONSUMER = "SELECT consumer_num,consumer_name,address FROM Consumers WHERE consumer_num = ?";
	public static final String BILL_DETAILS = "SELECT bill_num,TO_CHAR(bill_date,'MONTH'),cur_reading,unitConsumed,netAmount FROM BillDetails WHERE consumer_num=?";
	public static final String INSERT_DETAILS = "INSERT INTO BillDetails VALUES(seq_bill_num.NEXTVAL,?,?,?,?,SYSDATE)";
	public static final String GET_DETAILS = "SELECT consumer_name FROM Consumers WHERE consumer_num = ?";
	public static final String GET_SEQUENCEVALUE = "SELECT seq_bill_num.currval FROM DUAL";
}
