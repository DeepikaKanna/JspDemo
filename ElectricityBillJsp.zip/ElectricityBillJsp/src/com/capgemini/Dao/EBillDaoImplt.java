package com.capgemini.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;



import com.capgemini.Bean.BillDetails;
import com.capgemini.Bean.ConsumerBean;
import com.capgemini.Util.DBConnection;
import com.capgemini.Dao.IQuerryMapper;
import com.capgemini.Exception.EBillException;


public class EBillDaoImplt implements IEBillDao{

	@Override
	public ArrayList<ConsumerBean> ConsumerList() throws EBillException, SQLException {
		ArrayList<ConsumerBean> list = new ArrayList<ConsumerBean>();
		
		try {
			Connection con = DBConnection.getConnection();
			PreparedStatement st =  con.prepareStatement(IQuerryMapper.CONSUMER_LIST);
			ResultSet rs = st.executeQuery();
			while(rs.next()){
				ConsumerBean bean = new ConsumerBean();
				bean.setConsumerNum(rs.getInt("consumer_num"));
				bean.setConsumerName(rs.getString("consumer_name"));
				bean.setAddress(rs.getString("address"));
				list.add(bean);
			}
		} 
		catch (Exception e) {
			throw new EBillException(e.getMessage());
		}
		
	return list;
}

	@Override
	public ConsumerBean searchConsumer(int consumerNum) throws EBillException, SQLException{
		ConsumerBean bean = new ConsumerBean();
		
		try {
			Connection con = DBConnection.getConnection();
			PreparedStatement st =  con.prepareStatement(IQuerryMapper.SEARCH_CONSUMER);
			st.setInt(1, consumerNum);
			ResultSet rs = st.executeQuery();
			if(rs.next()){
				bean.setConsumerNum(rs.getInt("consumer_num"));
				bean.setConsumerName(rs.getString("consumer_name"));
				bean.setAddress(rs.getString("address"));
			}
		} 
		catch (Exception e) {
			throw new EBillException(e.getMessage());
		}
		
	return bean;
	}

	@Override
	public ArrayList<BillDetails> getConsumerBills(int consumerNum)
			throws EBillException, SQLException {
		
		ArrayList<BillDetails> list = new ArrayList<BillDetails>();
		
		try {
			Connection con = DBConnection.getConnection();
			PreparedStatement st =  con.prepareStatement(IQuerryMapper.BILL_DETAILS);
			st.setInt(1, consumerNum);
			ResultSet rs = st.executeQuery();
			while(rs.next()){
				BillDetails bill = new BillDetails();
				bill.setBillNumber(rs.getInt(1));
				bill.setBillMonth(rs.getString(2));
				bill.setMonthReading(rs.getFloat(3));
				bill.setUnitConsumed(rs.getFloat(4));
				bill.setBillAmount(rs.getFloat(5));
				list.add(bill);
			}
		} 
		catch (Exception e) {
			throw new EBillException(e.getMessage());
		}
		
		
		return list;
	}

	@Override
	public int addBillDetails(BillDetails bill) throws EBillException,
			SQLException {
		int billNum = 0;
		
		int cusNum = bill.getConsumerNum();
		float curReading = bill.getMonthReading();
		float unitConsumed = bill.getUnitConsumed();
		float billAmount = bill.getBillAmount();
		
		Connection con = DBConnection.getConnection();
		PreparedStatement st =  con.prepareStatement(IQuerryMapper.INSERT_DETAILS);
		st.setInt(1,cusNum);
		st.setFloat(2, curReading);
		st.setFloat(3, unitConsumed);
		st.setFloat(4, billAmount);
		int rows=0;
		try{
			rows = st.executeUpdate();
		}
		catch(SQLException e){
			throw new EBillException(""+cusNum);
		}
		
		if(rows > 0 ){
			st =  con.prepareStatement(IQuerryMapper.GET_SEQUENCEVALUE);
			ResultSet rs = st.executeQuery();
			
			if(rs.next()){
				billNum = Integer.parseInt(rs.getString(1));
				bill.setBillNumber(billNum);
			}
			
		}
	
		
		
		return billNum;
	}

}
