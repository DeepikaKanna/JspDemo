package com.capgemini.Util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.capgemini.Exception.EBillException;

public class DBConnection {
	public static Connection getConnection() throws EBillException{
		InitialContext ic;

		try {
			ic = new InitialContext();
			DataSource ds = (DataSource)ic.lookup("java:/OracleDS");
			Connection con = ds.getConnection();
			return con;
		}
		catch (NamingException e) {
			throw new EBillException(e.getMessage());
		} 
		catch (SQLException e) {
			throw new EBillException(e.getMessage());
		}
	}
}
