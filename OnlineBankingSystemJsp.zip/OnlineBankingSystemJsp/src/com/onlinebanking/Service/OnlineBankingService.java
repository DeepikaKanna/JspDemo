package com.onlinebanking.Service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.onlinebanking.Bean.OnlineBankingBean;
import com.onlinebanking.Dao.IonlineBankingDao;
import com.onlinebanking.Dao.OnlineBankingDao;
import com.onlinebanking.Exception.OnlineBankingException;

public class OnlineBankingService implements IonlineBankingService{

	@Override
	public ArrayList<Long> getAccounts(long userId) throws OnlineBankingException{
		IonlineBankingDao ibd=new OnlineBankingDao();
		
		ArrayList<Long> accounts=ibd.getAccounts(userId);
		
		return accounts;
	}

	@Override
	public ArrayList<OnlineBankingBean> getMiniStatement(long acc_no) throws OnlineBankingException {
		IonlineBankingDao ibd=new OnlineBankingDao();
		ArrayList<OnlineBankingBean> miniStatement=ibd.getMiniStatement(acc_no);
		return miniStatement;
	}
	
	@Override
	public String validateUser(long userId, String password) throws OnlineBankingException, SQLException {
		
		IonlineBankingDao ibd=new OnlineBankingDao();
		String result = ibd.validateUser(userId, password);
		
		return result;
	}

	@Override
	public boolean getRegistered(OnlineBankingBean userbean) throws OnlineBankingException, SQLException {
		IonlineBankingDao ibd=new OnlineBankingDao();
		boolean result = ibd.getRegistered(userbean);
		return result;
	}
	
	@Override
	public ArrayList<OnlineBankingBean> getDetailedStatement(long acc_no,String fromDate,String toDate) throws OnlineBankingException {
		IonlineBankingDao ibd=new OnlineBankingDao();
		ArrayList<OnlineBankingBean> detailedStatement=ibd.getdetailedStatement(acc_no,fromDate,toDate);
		return detailedStatement;// TODO Auto-generated method stub
		
	}
	

	@Override
	public String getEmailId(long accountNo) throws OnlineBankingException{
		IonlineBankingDao ibd=new OnlineBankingDao();
		String email=ibd.getEmailId(accountNo);
		return email;
	}

	@Override
	public String updateEmail(long acc_no, String email, String existingemail) throws OnlineBankingException{
		IonlineBankingDao ibd=new OnlineBankingDao();
		String updateEmailId=ibd.updateEmailId(acc_no,email,existingemail);
		return updateEmailId;
	}

	@Override
	public String getAddress(long accountNo) throws OnlineBankingException{
		IonlineBankingDao ibd=new OnlineBankingDao();
		String address=ibd.getAddress(accountNo);
		return address;
	}
	
	@Override
	public String updateAddress(long acc_no, String address, String existingAddress) throws OnlineBankingException{
		IonlineBankingDao ibd=new OnlineBankingDao();
		
		String updateEmailId=ibd.updateAddress(acc_no,address,existingAddress);
		
		return updateEmailId;
	}

	@Override
	public void blockUserId(long key) throws OnlineBankingException{
		IonlineBankingDao ibd=new OnlineBankingDao();
		
		ibd.blockUserId(key);
		
		return;
	}

	@Override
	public String validateSecretAnswer(String question, String answer, long userId) throws OnlineBankingException{
		IonlineBankingDao ibd=new OnlineBankingDao();
		
		String result = ibd.validateSecretAnswer(question,answer,userId);
		
		return result;
	}

	@Override
	public String changePassword(String password,long userId) throws OnlineBankingException{
		IonlineBankingDao ibd=new OnlineBankingDao();
		
		String result = ibd.changePassword(password,userId);
				
		return result;
	}

	@Override
	public String raiseCheckBookRequest(long accountNo, String description) throws OnlineBankingException{
		IonlineBankingDao ibd=new OnlineBankingDao();
		String raiseCheckBookRequest=ibd.raiseCheckBookRequest(accountNo,description);
		return raiseCheckBookRequest;
	}

	@Override
	public ArrayList<OnlineBankingBean> getCheckBookService(long service_id) throws OnlineBankingException{
		IonlineBankingDao ibd=new OnlineBankingDao();
		ArrayList<OnlineBankingBean> serviceRequestDetails=new ArrayList<OnlineBankingBean>();
		serviceRequestDetails=ibd.getServiceRequestDetails(service_id);
		return serviceRequestDetails;
	}

	@Override
	public ArrayList<Long> getPayeeAccounts(long uid) throws OnlineBankingException{
		IonlineBankingDao ibd=new OnlineBankingDao();
		ArrayList<Long> PayeeAccounts=ibd.getPayeeAccounts(uid);
		return PayeeAccounts;
	}

	@Override
	public String transferFunds(long accountNo, long payeeAccount,
			String transferDesc,long amount,String transpwd) throws OnlineBankingException{
		IonlineBankingDao ibd=new OnlineBankingDao();
		String transferFunds=ibd.transferFunds(accountNo,payeeAccount,transferDesc,amount,transpwd);
		return transferFunds;
	}

	@Override
	public ArrayList<OnlineBankingBean> getCheckBookAccountService(long acc_no) throws OnlineBankingException{
		IonlineBankingDao ibd=new OnlineBankingDao();
		ArrayList<OnlineBankingBean> AccountserviceRequestDetails=new ArrayList<OnlineBankingBean>();
		AccountserviceRequestDetails=ibd.getAccountServiceRequestDetails(acc_no);
		return AccountserviceRequestDetails;
	}

	@Override
	public String createAccount(OnlineBankingBean ob) throws OnlineBankingException{
		IonlineBankingDao ibd=new OnlineBankingDao();
		String createAccount=ibd.createAccount(ob);
		return createAccount;
	}

	@Override
	public ArrayList<OnlineBankingBean> getYearlyTransaction(int year) throws OnlineBankingException{
		ArrayList<OnlineBankingBean> transactionYear=new ArrayList<OnlineBankingBean>();
		IonlineBankingDao ibd=new OnlineBankingDao();
		transactionYear=ibd.getTransactionYear(year);
		return transactionYear;
	}
	
	@Override
	public ArrayList<OnlineBankingBean> getMonthlyTransaction(int month) throws OnlineBankingException{
		ArrayList<OnlineBankingBean> transactionMonth=new ArrayList<OnlineBankingBean>();
		IonlineBankingDao ibd=new OnlineBankingDao();
		transactionMonth=ibd.getTransactionMonth(month);
		return transactionMonth;
	}
	
	@Override
	public ArrayList<OnlineBankingBean> getDailyTransaction(int date) throws OnlineBankingException{
		ArrayList<OnlineBankingBean> transactionDate=new ArrayList<OnlineBankingBean>();
		IonlineBankingDao ibd=new OnlineBankingDao();
		transactionDate=ibd.getTransactionDate(date);
		return transactionDate;
	}
	@Override
	public ArrayList<Long> getAccountNumbers(long useri) throws OnlineBankingException{
		IonlineBankingDao ibd=new OnlineBankingDao();
		ArrayList<Long> arr=ibd.getAccountNumbers(useri);
		return arr;
	}

	@Override
	public boolean insertPayeeAccount(long user, long pid, String name) throws OnlineBankingException {
		
		IonlineBankingDao ibd=new OnlineBankingDao();
		boolean res=ibd.insertPayeeAccount(user,pid,name);
		return res;
	}

	@Override
	public ArrayList<Long> getAccountNo(long user) throws OnlineBankingException {
		
		IonlineBankingDao ibd=new OnlineBankingDao();
		 ArrayList<Long> acc=ibd.getAccountNo(user);
		return acc;
	}

	@Override
	public ArrayList<Long> getpayee(long useri) throws OnlineBankingException {
		
		IonlineBankingDao ibd=new OnlineBankingDao();
		 ArrayList<Long> acc=ibd.getpayee(useri);
		return acc;
	
	}

	@Override
	public ArrayList<Long> getuser(long useri) throws OnlineBankingException {
		
		IonlineBankingDao ibd=new OnlineBankingDao();
		 ArrayList<Long> acc=ibd.getuser(useri);
		return acc;
		
	}

	@Override
	public boolean isValidPayee(long pid) throws OnlineBankingException {
		IonlineBankingDao ibd=new OnlineBankingDao();
		boolean res=ibd.isValidPayee(pid);
		return res;

	}

}
